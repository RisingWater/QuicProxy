
#include <winpr/crt.h>
#include <winpr/sspi.h>

int TestCredSSP(int argc, char* argv[])
{
	return 0;
}
