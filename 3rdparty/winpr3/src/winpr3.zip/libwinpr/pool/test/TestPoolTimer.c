
#include <winpr/crt.h>
#include <winpr/pool.h>

int TestPoolTimer(int argc, char* argv[])
{
	return 0;
}
