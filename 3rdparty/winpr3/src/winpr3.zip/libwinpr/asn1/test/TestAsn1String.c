
#include <stdio.h>
#include <winpr/crt.h>
#include <winpr/asn1.h>
#include <winpr/winpr.h>

int TestAsn1String(int argc, char* argv[])
{
	return 0;
}
